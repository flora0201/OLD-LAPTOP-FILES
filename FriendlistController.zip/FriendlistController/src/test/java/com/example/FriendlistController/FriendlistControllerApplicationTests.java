package com.example.FriendlistController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendlistControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
