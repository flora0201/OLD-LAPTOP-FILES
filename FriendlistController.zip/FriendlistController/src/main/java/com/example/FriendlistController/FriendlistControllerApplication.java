package com.example.FriendlistController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendlistControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendlistControllerApplication.class, args);
	}

}
