package com.example.Javaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
