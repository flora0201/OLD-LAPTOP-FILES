package com.example.Demoprojcet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoprojcetApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoprojcetApplication.class, args);
	}

}
