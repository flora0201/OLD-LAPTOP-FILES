package com.example.Demoprojcet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoprojcetApplicationTests {

	@Test
	void contextLoads() {
	}

}
