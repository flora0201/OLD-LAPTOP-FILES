package com.example.Getrequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetrequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetrequestApplication.class, args);
	}

}
