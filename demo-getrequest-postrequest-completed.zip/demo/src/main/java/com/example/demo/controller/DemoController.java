package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@RestController
public class DemoController {
    
    // @GetMapping(path = "/hi")
    @RequestMapping(
        value = "/hi", 
        method = RequestMethod.GET 
    )
    public String hi() {
        return "Hello World!";
    }

    @GetMapping(path = "/")
    public String rootURL() {
        return "You are in main Page";
    }

    @GetMapping(path = "/api/getparameters")
    public String getParam(@RequestParam String name) {

        System.out.println("\n\n\n\n\n\n");
        System.out.println(name);
        String response = "Hi "+name;
        return response;
    }

    @PostMapping(path = "/api/postparameters")
    public String postParam(WebRequest webRequest) {
        String firstname = webRequest.getParameter("a");
        String lastname = webRequest.getParameter("b");
        String response = "Hi "+ firstname + " " + lastname;
        return response;
    }
}