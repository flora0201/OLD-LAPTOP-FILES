package com.friendlist.friendlist.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Friend {
    private String firstname;
    private String lastname;
}