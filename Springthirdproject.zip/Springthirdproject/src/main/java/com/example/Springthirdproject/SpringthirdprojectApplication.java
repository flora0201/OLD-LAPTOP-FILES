package com.example.Springthirdproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringthirdprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringthirdprojectApplication.class, args);
	}

}
