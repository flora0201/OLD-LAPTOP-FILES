package com.example.Springsecondproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecondprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecondprojectApplication.class, args);
	}

}
