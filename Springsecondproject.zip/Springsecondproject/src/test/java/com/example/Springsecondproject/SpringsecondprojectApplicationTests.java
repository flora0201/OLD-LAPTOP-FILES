package com.example.Springsecondproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecondprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
